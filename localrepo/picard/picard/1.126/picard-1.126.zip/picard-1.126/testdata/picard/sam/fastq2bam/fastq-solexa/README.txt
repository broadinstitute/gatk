
s_1_sequence.txt - from /seq/solexa_archive/gerald_archive/305LWAAXX080721/s_1_sequence.txt

bad1.fastq
solexa_full_range_as_sanger.fastq
solexa_full_range_as_solexa.fastq

