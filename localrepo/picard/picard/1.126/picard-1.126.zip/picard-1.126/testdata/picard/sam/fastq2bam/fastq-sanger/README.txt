

sanger_full_range_as_sanger-63.fastq - all sanger chars - from BioPython distro 

5k-30BB2AAXX.3.aligned.sam.fastq

5k-v1-Rhodobacter_LW1.sam.fastq
