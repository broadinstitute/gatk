
sorted-pair.sam - 5 sorted pairs (10 records) - mate1, mate2
first-mate-bof-last-mate-eof.sam - :01 mate1, 4 pairs, :01 mate2
last-pair-mates-flipped.sam  - last pair's mates flipped - mate2, mate1
